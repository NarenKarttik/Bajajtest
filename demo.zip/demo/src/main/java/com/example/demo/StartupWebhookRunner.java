package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class StartupWebhookRunner implements CommandLineRunner {
    @Override
    public void run(String... args) throws Exception {
        String url = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";
        RestTemplate restTemplate = new RestTemplate();
        ObjectMapper mapper = new ObjectMapper();
        String requestBody = "{" +
                "\"name\": \"Naren Karttik\"," +
                " \"regNo\": \"22BCE1088\"," +
                " \"email\": \"narenkarttiks@gmail.com\"}";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);
        if (response.getStatusCode().is2xxSuccessful()) {
            JsonNode json = mapper.readTree(response.getBody());
            String webhook = json.has("webhook") ? json.get("webhook").asText() : "N/A";
            String accessToken = json.has("accessToken") ? json.get("accessToken").asText() : "N/A";
            System.out.println("Webhook URL: " + webhook);
            System.out.println("Access Token: " + accessToken);

            // Prepare POST request to webhook
            String sqlQuery = """
                SELECT 
                    e1.EMP_ID, 
                    e1.FIRST_NAME, 
                    e1.LAST_NAME, 
                    d.DEPARTMENT_NAME, 
                    COUNT(e2.EMP_ID) AS YOUNGER_EMPLOYEES_COUNT
                FROM 
                    EMPLOYEE e1
                JOIN 
                    DEPARTMENT d ON e1.DEPARTMENT = d.DEPARTMENT_ID
                LEFT JOIN 
                    EMPLOYEE e2 ON e1.DEPARTMENT = e2.DEPARTMENT 
                        AND e2.DOB > e1.DOB
                GROUP BY 
                    e1.EMP_ID, e1.FIRST_NAME, e1.LAST_NAME, d.DEPARTMENT_NAME
                ORDER BY 
                    e1.EMP_ID DESC;
                """;
            String webhookBody = "{\"finalQuery\": \"" + sqlQuery.replace("\"", "\\\"").replace("\n", " ").replace("  ", " ") + "\"}";
            HttpHeaders webhookHeaders = new HttpHeaders();
            webhookHeaders.setContentType(MediaType.APPLICATION_JSON);
            webhookHeaders.set("Authorization", accessToken);
            HttpEntity<String> webhookEntity = new HttpEntity<>(webhookBody, webhookHeaders);
            ResponseEntity<String> webhookResponse = restTemplate.postForEntity(webhook, webhookEntity, String.class);
            System.out.println("Webhook POST response: " + webhookResponse.getBody());
        } else {
            System.out.println("Failed to get webhook. Status: " + response.getStatusCode());
        }
    }
}
