package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BajajTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BajajTestApplication.class, args);
	}

}
